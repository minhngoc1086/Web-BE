﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _24DH110457_MyStore.Models.ViewModel
{
    public class ProductSearchVM
    {
    }
}